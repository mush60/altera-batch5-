
def count_m(a,b) :
    return a * b


m = int(input("masukan nilai m : "))
a = int(input("masukan nilai a : "))

newton = count_m(m,a)

print("gaya yang di hasilkan : %d" % (newton))